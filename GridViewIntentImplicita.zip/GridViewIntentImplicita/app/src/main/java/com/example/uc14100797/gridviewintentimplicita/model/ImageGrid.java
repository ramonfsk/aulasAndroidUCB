package com.example.uc14100797.gridviewintentimplicita.model;

/**
 * Created by UC14100797 on 12/09/2018.
 */

public class ImageGrid {


}
