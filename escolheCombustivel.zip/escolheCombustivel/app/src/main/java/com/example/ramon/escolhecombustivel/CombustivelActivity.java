package com.example.ramon.escolhecombustivel;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CombustivelActivity extends Activity implements View.OnClickListener {

    EditText edtAlcool, edtGasolina;
    Button btnCalcula;
    Double vlrAlcool, vlrGasolina;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_combustivel);
        edtAlcool = findViewById(R.id.edtVlrAlc);
        edtGasolina = findViewById(R.id.edtVlrGas);
        btnCalcula = findViewById(R.id.btnCalc);

        btnCalcula.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.btnCalc){
            String txtAlcool = edtAlcool.getText().toString();
            String txtGasolina = edtGasolina.getText().toString();

            vlrAlcool = Double.parseDouble(txtAlcool);
            vlrGasolina = Double.parseDouble(txtGasolina);
            Double percentCombust = (vlrAlcool/vlrGasolina);

            if(percentCombust < 0.7){
                Toast.makeText(this, "O alcool está mais em conta!", Toast.LENGTH_LONG).show();
            }else{
                Toast.makeText(this, "A gasolina está mais em conta!", Toast.LENGTH_LONG).show();
            }
        }
    }
}
