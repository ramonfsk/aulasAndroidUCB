package com.example.ramon.escolhecombustivel;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends Activity implements View.OnClickListener {

    Button btnCombustivel, btnAutonomia;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnCombustivel = findViewById(R.id.btnCombustivel);
        btnAutonomia = findViewById(R.id.btnAutonomia);

        btnCombustivel.setOnClickListener(this);
        btnAutonomia.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.btnCombustivel: {
                intent = new Intent(getApplicationContext(), CombustivelActivity.class);
                startActivity(intent);
                break;
            }
            case R.id.btnAutonomia: {
                intent = new Intent(getApplicationContext(), AutonomiaActivity.class);
                startActivity(intent);
                break;
            }
        }
    }
}
