package com.example.ramon.escolhecombustivel;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AutonomiaActivity extends Activity implements View.OnClickListener {

    EditText edtTamTanque, edtKmRodado;
    Button btnAutonomia;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_autonomia);
        edtTamTanque =  findViewById(R.id.edtVlrTan);
        edtKmRodado =  findViewById(R.id.edtVlrKm);
        btnAutonomia = findViewById(R.id.btnCalcAut);

        btnAutonomia.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.btnCalcAut){
            String txtTamTanque = edtTamTanque.getText().toString();
            String txtKmRodado = edtKmRodado.getText().toString();

            Double vlrCapacidade = Double.parseDouble(txtTamTanque);
            Double vlrKmRodado = Double.parseDouble(txtKmRodado);
            Double vlrAutonomia = (vlrKmRodado/vlrCapacidade);
            Toast.makeText(this, "O consumo médio é "+ String.format("%.2f",vlrAutonomia) +" litros por KM rodado.", Toast.LENGTH_LONG).show();
        }
    }
}
